package com.bus.exceptions;

public class BusException extends Exception{

	public BusException() {
		
	}
	
	public BusException(String str) {
		super (str);
	}
}
