package com.bus.exceptions;

public class CustomerException extends Exception{
	
	public CustomerException(){
		
	}
	
	public CustomerException(String str){
		super(str);
	}

	
}
